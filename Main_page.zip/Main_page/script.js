function selectCategory(category) {
	switch (category) {
		case 'cardiology':
			window.location.href = "page.html";
			break;
		case 'dermatology':
			window.location.href = "page2.html";
			break;
		case 'gynecology':
			window.location.href = "gynecology.html";
			break;
		case 'neurology':
			window.location.href = "neurology.html";
			break;
	}
}
